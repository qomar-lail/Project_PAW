<?php
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "diary_learning_db";

$conn = new mysqli($servername, $username, $password, $db_name);

?>