<?php
include "controler/admin/sekolah_controller_admin.php";
sekolah_index_admin();




