<?php
include "controler/user/sekolah_controller_user.php";
sekolah_index()


?>